<svg width=auto height=30>
	<text x=0 y=20>ACME</text>
</svg>

<style>
	text {
		fill: currentColor
	}
</style>