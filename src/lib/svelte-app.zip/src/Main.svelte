<main class="p-4 text-gray-300">
	<svg height="100%" width="100%">
		<line x1=0 y1=4 x2=400 y2=4/>
		<line x1=0 y1=34 x2=200 y2=34/>
		<line x1=0 y1=64 x2=300 y2=64/>
		<line x1=0 y1=94 x2=280 y2=94/>
	</svg>
</main>

<style>
	svg line {
		stroke: currentColor;
		stroke-width: 12;
	}
</style>