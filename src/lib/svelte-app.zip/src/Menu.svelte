<nav class="hidden text-gray-500 uppercase text-bold sm:block">
  <a href="/about" class="hover:text-gray-700 hover:no-underline">About</a>
	<a href="/contact" class="hover:text-gray-700 hover:no-underline">Contact</a>
</nav>